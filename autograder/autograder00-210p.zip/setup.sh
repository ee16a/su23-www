#!/usr/bin/env bash

apt-get update -y
pip3 uninstall -y pyyaml
#apt-get install -y python python-pip libyaml-dev libpython2.7-dev python-dev
pip3 install pyyaml

pip3 install -r /autograder/source/requirements.txt
