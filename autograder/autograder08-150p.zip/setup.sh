#!/usr/bin/env bash

apt-get update -y
pip uninstall pyyaml
apt-get install -y python python-pip libyaml-dev libpython2.7-dev python-dev
pip install pyyaml

pip install -r /autograder/source/requirements.txt
